# Netlify部署指南

## 🎯 概述

本指南将带你完成GitHub仓库连接Netlify并配置自动部署的完整流程。

## 📋 部署前准备

### ✅ 确认清单
- [ ] 已有GitHub账户
- [ ] GitHub仓库已创建（推荐名称：`yuanxuetong-website`）
- [ ] 网站文件已上传到GitHub
- [ ] 准备一个邮箱地址

## 🚀 详细部署步骤

### 步骤1：注册Netlify账户

1. **访问Netlify**
   ```
   https://netlify.com
   ```

2. **点击"Sign up"**
   - 选择 "Sign up with GitHub"（推荐）
   - 或使用邮箱注册

3. **授权GitHub访问**
   - 登录GitHub账户
   - 授权Netlify访问你的GitHub账户
   - 授权仓库访问权限

### 步骤2：创建新项目

1. **进入Netlify控制台**
   - 登录后会看到 "Add new site" 选项

2. **选择部署方式**
   - 点击 "Import an existing project"
   - 选择 "Deploy with GitHub"

3. **选择GitHub仓库**
   - 从列表中找到你的 `yuanxuetong-website` 仓库
   - 点击 "Select repository"

### 步骤3：配置构建设置

1. **基本配置**
   ```
   Repository: yuanxuetong-website
   Branch to deploy: main（或master）
   Build command: echo 'Static website - no build required'
   Publish directory: .（点号表示根目录）
   ```

2. **高级设置（可选）**
   ```
   Environment variables: 
   - NODE_VERSION = 18
   
   Build settings:
   - Publish directory: ./
   - Build command: #留空或使用默认
   ```

### 步骤4：部署网站

1. **启动部署**
   - 点击 "Deploy site"
   - 系统开始处理

2. **等待部署**
   - 首次部署需要2-3分钟
   - 可观看实时构建日志

3. **获得访问URL**
   - 部署完成后会显示
   - 格式：`https://random-name.netlify.app`

### 步骤5：配置域名（可选）

1. **自定义域名**
   - 在Netlify项目设置中
   - 点击 "Domain management"
   - 添加自定义域名

2. **DNS配置**
   - CNAME记录指向生成的URL
   - A记录指向Netlify的IP

## 🔧 高级配置

### 环境变量设置

在Netlify项目设置中：

```bash
# 构建环境
NODE_VERSION=18
NPM_FLAGS=--production=false

# 网站配置
SITE_NAME=yuanxuetong-website
BUILD_TIMESTAMP=true
```

### 构建钩子

创建构建钩子用于手动触发：

1. 项目设置 → Build & deploy → Build hooks
2. 创建新的hook
3. 获得URL格式：`https://api.netlify.com/build_hooks/xxx`

### 表单处理

如需添加联系表单：

1. 在HTML中添加：
```html
<form name="contact" method="POST" data-netlify="true">
  <input type="hidden" name="form-name" value="contact">
  <p>
    <label>姓名: <input name="name" type="text"></label>
  </p>
  <p>
    <label>邮箱: <input name="email" type="email"></label>
  </p>
  <p>
    <button type="submit">发送</button>
  </p>
</form>
```

## 📊 监控和日志

### 查看部署状态

1. **Netlify控制台**
   - 项目 → Deploys
   - 查看所有部署记录

2. **GitHub集成**
   - GitHub仓库会显示Netlify部署状态
   - 绿色勾号表示成功，红色叉号表示失败

### 日志分析

1. **构建日志**
   - 点击任意部署记录
   - 查看详细构建信息
   - 排查错误和问题

2. **访问日志**
   - Analytics → Traffic
   - 查看访问量和地理位置

## 🔄 自动部署工作流

### 触发条件

以下操作会触发自动部署：
- 推送到主分支（main/master）
- 创建Pull Request
- 合并分支到主分支

### 部署流程

```
1. 代码提交 → GitHub
2. GitHub通知 → Netlify  
3. Netlify拉取 → 最新代码
4. 构建检查 → （静态网站无构建）
5. 部署发布 → 全球CDN
6. 通知完成 → 预览链接
```

### 预览功能

- **分支预览**：每个分支都有独立预览
- **PR预览**：Pull Request自动创建预览
- **快照预览**：任意提交都有独立URL

## ⚡ 性能优化

### CDN配置

Netlify默认提供全球CDN：
- 100+边缘节点
- 智能路由
- 自动缓存

### 缓存策略

在 `netlify.toml` 中配置：

```toml
[[headers]]
  for = "/assets/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000"
```

### 压缩设置

```toml
[build]
  environment = { NODE_VERSION = "18" }
  
[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
```

## 🔒 安全配置

### HTTPS证书

- ✅ 自动获得Let's Encrypt证书
- ✅ 自动续期
- ✅ 支持HSTS
- ✅ HTTP自动重定向HTTPS

### 安全头

在 `netlify.toml` 中：

```toml
[[headers]]
  for = "/*"
  [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
```

## 🎯 部署检查清单

### 部署前
- [ ] GitHub仓库已创建
- [ ] 所有文件已上传
- [ ] netlify.toml配置正确
- [ ] GitHub和Netlify账户已连接

### 部署后
- [ ] 网站可正常访问
- [ ] HTTPS证书有效
- [ ] 图片资源加载正常
- [ ] 移动端显示正常
- [ ] 所有链接功能正常

### 功能测试
- [ ] 导航菜单工作
- [ ] 图片轮播功能
- [ ] 联系方式正确
- [ ] 页面加载速度满意
- [ ] SEO元数据完整

## 📞 故障排除

### 部署失败

**问题**：构建失败
**解决**：
1. 检查netlify.toml配置
2. 确认没有语法错误
3. 查看构建日志详情

### 404错误

**问题**：页面找不到
**解决**：
1. 检查文件路径
2. 确认index.html存在
3. 配置SPA路由

### 图片加载失败

**问题**：图片不显示
**解决**：
1. 检查图片路径
2. 确认文件大小合理
3. 使用支持的图片格式

### 样式异常

**问题**：CSS样式丢失
**解决**：
1. 检查CSS文件路径
2. 确认文件名正确
3. 查看浏览器控制台错误

## 🎉 部署成功标志

部署成功后，你将获得：
- ✅ 稳定的 `.netlify.app` 访问地址
- ✅ 全球CDN加速
- ✅ 自动HTTPS证书
- ✅ 自动部署流程
- ✅ 版本管理支持
- ✅ 预览功能

---

**恭喜！你的网站现在拥有了专业级的部署和访问体验！** 🚀