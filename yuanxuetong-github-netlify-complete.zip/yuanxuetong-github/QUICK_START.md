# 🚀 快速开始：GitHub + Netlify 部署指南

## ⚡ 5分钟部署完成

跟随这个快速指南，立即部署你的网站！

---

## 🎯 目标

将渊学通网站部署到Netlify，获得稳定访问地址：
- ❌ 原址：`https://tlm37duflo40.space.minimax.io`（有访问问题）
- ✅ 新址：`https://yuanxuetong-random123.netlify.app`（稳定可靠）

---

## 📋 第一步：准备GitHub仓库（3分钟）

### 1.1 创建GitHub仓库

1. **访问GitHub**
   ```
   https://github.com
   ```

2. **创建新仓库**
   - 点击右上角 "+" → "New repository"
   - 仓库名称：`yuanxuetong-website`
   - 描述：`渊学通国际教育官网`
   - 选择 "Public"
   - 勾选 "Add a README file"
   - 点击 "Create repository"

### 1.2 上传网站文件

**方法A：网页上传（推荐）**

1. **进入仓库页面**
   - 点击你刚创建的仓库

2. **上传文件**
   - 点击 "uploading an existing file"
   - 拖拽或选择所有网站文件：
     - `index.html`
     - `assets/` 文件夹
     - `images/` 文件夹
     - `imgs/` 文件夹
   - 填写提交信息：`初始部署 - 上传网站文件`
   - 点击 "Commit changes"

**方法B：克隆到本地**

```bash
# 克隆仓库
git clone https://github.com/your-username/yuanxuetong-website.git
cd yuanxuetong-website

# 复制文件到仓库目录
# 将所有网站文件复制到这里

# 提交上传
git add .
git commit -m "初始部署 - 上传网站文件"
git push origin main
```

---

## 🌐 第二步：部署到Netlify（2分钟）

### 2.1 连接Netlify

1. **访问Netlify**
   ```
   https://netlify.com
   ```

2. **注册/登录**
   - 点击 "Sign up with GitHub"
   - 授权GitHub访问

### 2.2 创建新项目

1. **添加新站点**
   - 点击 "Add new site"
   - 选择 "Import an existing project"
   - 选择 "Deploy with GitHub"

2. **选择仓库**
   - 找到 `yuanxuetong-website`
   - 点击 "Select repository"

### 2.3 配置部署

1. **基本设置**
   ```
   Repository: yuanxuetong-website
   Branch: main
   Build command: echo 'Static website - no build required'
   Publish directory: . (点号)
   ```

2. **高级设置**
   ```
   Environment variables:
   - NODE_VERSION = 18
   ```

3. **开始部署**
   - 点击 "Deploy site"
   - 等待2-3分钟完成

### 2.4 获得访问地址

部署成功后，你会看到：
- **状态**：绿色 "Published"
- **访问地址**：`https://random-name-xxx.netlify.app`
- **部署时间**：显示完成时间

---

## ✅ 第三步：验证部署（30秒）

### 3.1 访问测试

1. **点击访问地址**
   - 确保网站正常打开
   - 检查所有页面加载

2. **功能测试**
   - ✅ 首页显示正常
   - ✅ 图片加载完成
   - ✅ 导航菜单工作
   - ✅ 移动端适配正常

3. **HTTPS检查**
   - 确认URL是 `https://` 开头
   - 无安全警告

---

## 🎉 成功！你的网站现在在这里：

```
原址（有问题）：https://tlm37duflo40.space.minimax.io
新址（稳定）：https://your-new-url.netlify.app
```

---

## 🔄 第四步：未来修改流程（可选）

现在你可以体验GitHub自动部署的强大功能：

### 修改网站内容

1. **访问GitHub仓库**
   ```
   https://github.com/your-username/yuanxuetong-website
   ```

2. **编辑文件**
   - 点击要修改的文件
   - 点击编辑按钮（铅笔图标）
   - 修改内容

3. **提交更改**
   - 填写修改说明
   - 点击 "Commit changes"

4. **等待自动部署**
   - Netlify自动开始部署
   - 1-2分钟后获得新预览

### 查看部署状态

1. **Netlify控制台**
   ```
   https://app.netlify.com/
   ```

2. **GitHub仓库**
   - 绿色勾号表示部署成功
   - 红色叉号表示部署失败

---

## 🆘 遇到问题？

### 常见问题解决

**Q：上传文件失败？**
A：检查文件大小，确保每个文件不超过25MB

**Q：部署失败？**
A：查看Netlify部署日志，检查是否有语法错误

**Q：网站显示空白？**
A：确认index.html文件存在且在根目录

**Q：图片不显示？**
A：检查图片路径是否正确，使用相对路径

### 快速修复

1. **重新上传文件**
   - 删除有问题的文件
   - 重新上传正确的文件

2. **手动触发部署**
   - 在Netlify项目页面
   - 点击 "Trigger deploy" → "Deploy site"

3. **检查网络连接**
   - 确保GitHub和Netlify都能正常访问

---

## 📚 更多资源

- 📖 **完整指南**：`NETLIFY_DEPLOY.md`
- 🎯 **GitHub操作**：`GITHUB_GUIDE.md`
- 📞 **技术支持**：Netlify文档 https://docs.netlify.com/

---

## 🎯 立即开始

1. **现在**：注册GitHub → https://github.com
2. **然后**：注册Netlify → https://netlify.com  
3. **最后**：按步骤部署完成

**预计总时间：5-10分钟**

🚀 **立即开始部署，解决访问问题！**