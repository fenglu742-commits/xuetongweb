# 渊学通国际教育官网

## 项目简介

渊学通国际教育官网，展示AP课程、IB课程、一对一辅导等国际教育服务。

## 功能特性

- 📱 响应式设计，支持移动端和桌面端
- 🎨 现代化UI设计
- 📚 课程信息展示
- 👥 师资团队介绍
- 🏆 成功案例展示
- 📞 联系信息

## 技术栈

- HTML5 / CSS3 / JavaScript
- React.js
- Tailwind CSS
- Netlify自动部署

## 部署方式

### Netlify自动部署（推荐）

1. GitHub代码更新后自动部署
2. 支持预览功能
3. 全球CDN加速
4. 自动HTTPS证书

### 手动部署

```bash
# 直接上传文件到静态网站托管服务
# 或使用Netlify CLI
netlify deploy --prod
```

## 开发指南

### 本地开发

```bash
# 启动本地服务器
python -m http.server 8000
# 或使用Node.js
npx serve .
```

### 修改网站

1. 访问GitHub仓库
2. 在线编辑文件
3. 提交更改
4. 等待自动部署完成

## 项目结构

```
├── index.html          # 主页面
├── assets/             # JavaScript和CSS文件
├── images/             # 图片资源
├── imgs/               # 额外图片
└── README.md           # 项目说明
```

## 联系方式

- 官网：https://yuanxuetong.netlify.app
- 邮箱：info@yuanxuetong.com

## 许可证

MIT License

---

**由Netlify自动部署驱动** 🚀